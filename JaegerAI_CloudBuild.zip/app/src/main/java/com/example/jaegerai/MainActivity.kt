package com.example.jaegerai

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 12, 15)
    private val panel = Color.rgb(27, 27, 33)
    private val red = Color.rgb(235, 40, 55)
    private val white = Color.rgb(245, 245, 247)
    private val muted = Color.rgb(165, 165, 175)
    private lateinit var status: TextView
    private lateinit var autoButton: Button
    private var running = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(20))
            setBackgroundColor(bg)
        }

        val brand = text("REDMAGIC  •  GAME TOOLS", 12, red, true)
        page.addView(brand)

        val title = text("JAEGER AI", 30, white, true)
        title.setPadding(0, dp(8), 0, dp(2))
        page.addView(title)
        page.addView(text("NOOMICLONE  /  ПРОТОТИП 0.1", 11, muted, false))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(panel)
        }
        val cardParams = LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(26)
        }
        page.addView(card, cardParams)

        card.addView(text("СОСТОЯНИЕ СИСТЕМЫ", 11, muted, true))
        status = text("ОЖИДАНИЕ", 22, white, true)
        status.setPadding(0, dp(10), 0, dp(6))
        card.addView(status)
        card.addView(text(
            "Визуальное распознавание и игровой цикл ещё не подключены. " +
            "AUTO пока работает как демонстрационный переключатель.",
            13, muted, false
        ))

        autoButton = Button(this).apply {
            text = "AUTO  •  НЕАКТИВЕН"
            setTextColor(white)
            setBackgroundColor(red)
            isAllCaps = false
            textSize = 16f
            setOnClickListener {
                running = !running
                status.text = if (running) "ТЕСТОВЫЙ РЕЖИМ" else "ОЖИДАНИЕ"
                autoButton.text = if (running) "STOP  •  ОСТАНОВИТЬ" else "AUTO  •  НЕАКТИВЕН"
                autoButton.setBackgroundColor(if (running) Color.DKGRAY else red)
            }
        }
        val autoParams = LinearLayout.LayoutParams(-1, dp(58)).apply {
            topMargin = dp(22)
        }
        page.addView(autoButton, autoParams)

        val learn = button("НАСТРОЙКА СПЕЦИАЛЬНЫХ ВОЗМОЖНОСТЕЙ") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        page.addView(learn, buttonParams())

        val note = text(
            "ПЛАН УПРАВЛЕНИЯ\n" +
            "Arch — раскачка по фазам\n" +
            "Release — отпускание\n" +
            "Tuck — группировка\n" +
            "Автозахват — проверка счётчика\n" +
            "Винт и «Прилипание» — не используются",
            13, white, false
        )
        note.setPadding(dp(16), dp(16), dp(16), dp(16))
        note.setBackgroundColor(panel)
        val noteParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) }
        page.addView(note, noteParams)

        page.addView(text(
            "ПРЕДУПРЕЖДЕНИЕ: это исходный UI-прототип, а не готовый игровой автопилот. " +
            "Он не анализирует кадры и не нажимает кнопки в игре.",
            11, muted, false
        ).apply { setPadding(0, dp(18), 0, 0) })

        setContentView(page)
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(white)
        setBackgroundColor(panel)
        textSize = 12f
        setOnClickListener { action() }
    }

    private fun buttonParams() = LinearLayout.LayoutParams(-1, dp(52)).apply {
        topMargin = dp(10)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
