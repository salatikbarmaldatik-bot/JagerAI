package com.example.jaegerai

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/**
 * Safe placeholder for the future input controller.
 * Version 0.1 deliberately does not dispatch taps or gestures.
 */
class JaegerAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Screen interaction is not implemented in this prototype.
    }

    override fun onInterrupt() {
        // Nothing to interrupt yet.
    }
}
